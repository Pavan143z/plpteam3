import React, { Component } from "react";

export class App1 extends Component {
  constructor() {
    super();
    this.state = { display: false };
  }

  onChange = () => {
    this.setState({ display: !this.state.display });
  };

  render() {
    return (
      <div>
        <button onClick={this.onChange}>Change image</button>
        <br />
        {this.state.display ? (
          <img src={require("./photo1.jpeg")} />
        ) : (
                <img src={require("./photo2.jpg")} />
        )}
      </div>
    );
  }
}


export default App1;
