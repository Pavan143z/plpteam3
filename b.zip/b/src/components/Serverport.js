const mongoose= require('mongoose')
const Schema= mongoose.Schema;

const ServerPort = new Schema({
    companyname:{type: String},
    yearsworked:{type: Number},
    designation:{type: String},
    skills:{type: String}
},{
    collection: 'expusers'
})

module.exports= mongoose.model('expusers', ServerPort)
