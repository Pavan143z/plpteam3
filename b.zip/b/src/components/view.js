import React from 'react'
import Show from './show';
import axios from 'axios';
import Add from './add';

export class View extends React.Component {
    constructor() {
        super()
        this.state = { expuser: [] }

    }

    baseurl = "  http://localhost:3000/expuser";
    getContacts = () => {
        axios.get(this.baseurl).then((response) => {
        this.state = { expuser: [] }
        this.setState({ expuser: response.data })
        });
    }
    add = (contact) => {
        axios.post(this.baseurl, contact).then((response) => {
            this.getContacts();
            alert("details added")
        })
    }
   
    componentDidMount() {
        this.getContacts();
    }
    render() {
        return (
            <div>
                <h1> Experienced Users</h1>
                {/* <Add  />
                <Show expuser={this.state.expuser}  /> */}
            </div>

        )
    }
}
export default View;