import React from "react";
import axios from "axios";
import Show from "./show";

export class Add extends React.Component {
  constructor() {
    super();
    this.state = { display: true, expuser: [] };
  }

  companyname = React.createRef();
  yearsworked = React.createRef();
  designation = React.createRef();
  skills = React.createRef();
  compObject={
    companyname:"",
    yearsworked:"",
    designation:"",
    skills:"",


}
  baseurl = "  http://localhost:3000/expuser";

  handleAdd = () => {
    this.compObject = {
      companyname: this.companyname.current.value,
      yearsworked: this.yearsworked.current.value,
      designation: this.designation.current.value,
      skills: this.skills.current.value
    };
    console.log(this.compObject)
    axios.get(this.baseurl).then(response => {
      this.setState({ expuser: response.data });
    });

    axios.post(this.baseurl, this.compObject).then(response => {
      alert("details added");
    });
    this.setState({ display: !this.state.display });
  };

  onChange = () => {
    this.setState({ display: !this.state.display });
  };
  render() {
    return (
      <div className="well">
        {this.state.display ? (
          <div>
            <h1> Add your Details</h1>
            <form>
              {/* Add ref to input field */}
              Company Name:
              <input ref={this.companyname} />
              <br />
              <br />
              Years Worked: <input ref={this.yearsworked} />
              <br />
              <br />
              Designation: <input ref={this.designation} />
              <br />
              <br />
              Skills: <input ref={this.skills} />
              <br />
              <br />
              <button onClick={this.handleAdd} class="btn btn-success">
                ADD Experience
              </button>
            </form>
          </div>
        ) : (
          <div>
            <h1> Show Details</h1>

                <div>
                Company Name :   {this.compObject.companyname} <br/>
                 Years Worked :  {this.compObject.yearsworked}      <br/>
                Designation  :   {this.compObject.designation}      <br/>
                Skills       :   {this.compObject.skills}   <br/>
                

                <br/>
                <button className="btn btn-primary">Edit Details</button>
                <button className="btn btn-success" onClick={this.onChange}>Add more</button>
                </div>


             {/* <table border="1">
              <tr>
                <th>Company Name</th>
                <th>Years Worked</th>
                <th>Designation</th>
                <th>Skills</th>
                <th>
                  <button className="btn btn-primary">Edit Details</button>{" "}
                </th>
                <th>
                  <button className="btn btn-success" onClick={this.onChange}>Add more</button>{" "}
                </th>
              </tr>
              <tbody>
                {this.state.expuser.map(e => (
                  <tr key={e}>
                    <td>{e.companyname} </td>
                    <td>{e.yearsworked} </td>
                    <td>{e.designation} </td>
                    <td>{e.skills} </td>
                  </tr>
                ))}
              </tbody>
            </table>  */}



          </div>
        )}
      </div>
    );
  }
}
export default Add;
