import React from 'react';

import './App.css';
import Add from './components/add';
import App1 from './components/app1'

function App() {
  return (
    <div className="App">
     <h1>Backend Exp users</h1>

      <Add/>
      
    </div>
  );
}

export default App;
