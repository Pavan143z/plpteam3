import React from "react";
import { Link } from "react-router-dom";


class Home extends React.Component {
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-lg-6">
            <br />
            <br />
            <br />
            <h1 className="text-primary">
              Welcome to your professional community
            </h1>
          </div>
          <div className="col-lg-6">
            <br />
            <br />
            <br />
            <img
              src={require("../assets/images/images.png")}
              className="img-circle"
              width="500px"
              height="500px"
            />
          </div>
        </div>
      </div>
    );
  }
}

export default Home;
