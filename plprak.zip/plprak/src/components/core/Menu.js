import React from "react";
import { Link } from "react-router-dom";

export const Menu = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-dark">
      <div className="container-fluid">
        <div className="navbar-header">
          <Link className="navbar-brand" to="/">
            <img
              src={require("../assets/images/icon.png")}
              width="100px"
              height="40px"
            />
          </Link>
        </div>
        <div
          className="collapse navbar-collapse"
          id="bs-example-navbar-collapse-1"
        >
          <ul className="nav navbar-nav ">
            <li className="active" />
          </ul>
          <ul className="nav navbar-nav navbar-right">
            <br />
            <li>
              <Link to="/Signup">
                <h4>Register as User</h4>
              </Link>
            </li>
            <li>
              <Link to="/register">
                <h4>Register as Organization</h4>
              </Link>
            </li>
            <li>
              <Link to="/Login">
                <h4>Login as User</h4>
              </Link>
            </li>
            <li>
              <Link to="/Login2">
                <h4>Login as Organization</h4>
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Menu;
