import React, { Component } from 'react'

export class userprofile extends Component {
  render() {
    return (
      <div>
        <h1>Hello everyone</h1>
      </div>
    )
  }
}

export default userprofile
