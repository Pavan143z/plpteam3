module.exports = {
    DB: 'mongodb://localhost:27017/PlpProject'
}