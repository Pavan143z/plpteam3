const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyparser = require("body-parser");
const ServerPortRouter = require("./serverportrouter");

const app = express();
const PORT = 3001;

const config = require("./DB");

mongoose.connect(config.DB).then(
  () => {
    console.log("Database is connected");
  },
  err => {
    console.log("Can not connect to database" + err);
  }
);

app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());
app.use(cors());
app.use("/", ServerPortRouter);

app.listen(PORT, function() {
  console.log("Server is running on port number: ", PORT);
});
